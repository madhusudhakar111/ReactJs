import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Emp from './Emp';

class App extends Component {

  constructor(props){
    super(props);
    this.state = { displayListLength : 3, showList : true}
  }

    onChange(a){
        console.log('changeProps')
        this.setState({displayListLength:a});
    }

  render() {
    return (
      <div className="App">
        <ul>
          <li>
            {/*do a fetch api Call from one of the lifecycle methods , Api call written in comments use in Emp.js.*/}
            {/*let  obj =this;*/}
            {/*fetch('https://api.myjson.com/bins/18tldk')*/}
            {/*.then(function(response) {*/}
              {/*return response.json();*/}
          {/*})*/}
            {/*.then(function(myJson) {*/}
              {/*obj.setState({empData: myJson});*/}
          {/*});*/}
          </li>
          <li>
            on button click add a functionality to change props from App.js to Emp.js , basically change displayListLength from 3 to 2
           </li>
          <li>
            now new props are passed in second point , change the display length of empData state in accordance to displayListLength passed in props to Emp.js
          </li>
          <li>Add a check if showList prop is false then component should not update in Emp.js</li>
        </ul>
        <Emp displayListLength = {this.state.displayListLength} showList = {this.state.showList} propsChange = {this.onChange.bind(this)}/>
      </div>
    );
  }
}

export default App;
