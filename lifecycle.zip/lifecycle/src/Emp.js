import React, { Component } from 'react';
class Emp extends Component {

    constructor(props){
        super(props);
        this.state = { empData: [], textToDisplay:''}
    }

    componentWillMount(){
        console.log('Component will Mount');
        console.log(this.state)
    }

    componentWillReceiveProps(nextProps){
        console.log('will recieve props');
        const arrData = this.state.empData;
        if(nextProps.displayListLength !== this.props.displayListLength) {
            this.setState({empData: arrData.splice(0, arrData.length  - nextProps.displayListLength)});
        }
    }

    componentDidMount(){

       let  obj =this;
        fetch('https://api.myjson.com/bins/18tldk')
            .then(function(response) {
                return response.json();
            })
            .then(function(myJson) {
                obj.setState({empData: myJson});
            });
    }


    shouldComponentUpdate(nextProps, nextState){
        return nextProps.showList;
    }

    componentDidUpdate(prevProps, prevState){
        if(prevState.textToDisplay!=='All Done' && this.props.displayListLength ===3){

            this.setState({textToDisplay:'All Done'});
        }
    }

    changeProps = () => {
        this.props.propsChange(2);
    }

    render() {
        console.log('satte', this.state)
        let tbody = <tbody></tbody>;
        if(this.state.empData.length !==0){
            tbody = (
            <tbody>{this.state.empData.map(function(item, key) {

                return (
                    <tr key = {key}>
                        <td>{item.empid}</td>
                        <td>{item.empname}</td>
                        <td>{item.designation}</td>
                        <td>{item.salary}</td>
                    </tr>
                )

            })}</tbody>
        )}


        return (
            <div>
            <table width="35%">
                <tbody>

                <tr>
                    <td>Emp Id </td>
                    <td>Emp Name </td>
                    <td>Emp Designation </td>
                    <td>Emp salary </td>

                </tr>
                </tbody>

                {tbody}


            </table>
                <button onClick = {this.changeProps}>Click me </button>
                {this.state.textToDisplay}
            </div>
        )
    }
}

export default Emp;